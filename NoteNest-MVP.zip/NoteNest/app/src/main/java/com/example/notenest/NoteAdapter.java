package com.example.notenest;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import java.util.ArrayList;

public class NoteAdapter extends RecyclerView.Adapter<NoteAdapter.NoteHolder> {
    public interface Listener { void onOpen(Note note); void onShare(Note note); }
    private final ArrayList<Note> notes;
    private final String mode;
    private final Listener listener;

    public NoteAdapter(ArrayList<Note> notes, String mode, Listener listener) {
        this.notes = notes; this.mode = mode; this.listener = listener;
    }
    @NonNull @Override public NoteHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_note, parent, false);
        return new NoteHolder(view);
    }
    @Override public void onBindViewHolder(@NonNull NoteHolder h, int position) {
        Note n = notes.get(position);
        h.title.setText(n.title);
        String priceText = n.price <= 0 ? "FREE" : "৳" + (long)n.price;
        h.meta.setText(n.subject + "  •  " + priceText);
        h.preview.setText(n.content);
        h.preview.setMaxLines(3);
        if (mode.equals("mine")) {
            h.action.setText("Edit");
            h.action.setOnClickListener(v -> listener.onOpen(n));
            h.share.setVisibility(View.VISIBLE);
            h.share.setOnClickListener(v -> listener.onShare(n));
        } else if (mode.equals("market")) {
            h.action.setText(n.price <= 0 ? "Get free" : "Buy demo");
            h.action.setOnClickListener(v -> listener.onOpen(n));
            h.share.setVisibility(View.VISIBLE);
            h.share.setOnClickListener(v -> listener.onShare(n));
        } else {
            h.action.setText("Read");
            h.action.setOnClickListener(v -> listener.onOpen(n));
            h.share.setVisibility(View.GONE);
        }
    }
    @Override public int getItemCount() { return notes.size(); }
    static class NoteHolder extends RecyclerView.ViewHolder {
        TextView title, meta, preview; Button action, share;
        NoteHolder(@NonNull View v) {
            super(v); title=v.findViewById(R.id.tvTitle); meta=v.findViewById(R.id.tvMeta);
            preview=v.findViewById(R.id.tvPreview); action=v.findViewById(R.id.btnAction); share=v.findViewById(R.id.btnShare);
        }
    }
}
