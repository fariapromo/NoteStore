package com.example.notenest;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FirebaseFirestore;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

public class MainActivity extends AppCompatActivity implements NoteAdapter.Listener {
    private FirebaseFirestore db;
    private FirebaseAuth auth;
    private RecyclerView recycler;
    private TextView section;
    private ArrayList<Note> notes = new ArrayList<>();
    private String mode = "mine";

    @Override protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        db=FirebaseFirestore.getInstance(); auth=FirebaseAuth.getInstance();
        if (auth.getCurrentUser()==null) { openLogin(); return; }
        recycler=findViewById(R.id.rvNotes); section=findViewById(R.id.tvSection);
        recycler.setLayoutManager(new LinearLayoutManager(this));
        TextView greeting=findViewById(R.id.tvGreeting);
        greeting.setText("Welcome, " + auth.getCurrentUser().getEmail());
        findViewById(R.id.btnAdd).setOnClickListener(v -> startActivity(new Intent(this,AddEditNoteActivity.class)));
        findViewById(R.id.btnMine).setOnClickListener(v -> loadNotes("mine"));
        findViewById(R.id.btnExplore).setOnClickListener(v -> loadNotes("market"));
        findViewById(R.id.btnBought).setOnClickListener(v -> loadNotes("bought"));
        findViewById(R.id.btnLogout).setOnClickListener(v -> { auth.signOut(); openLogin(); });
        loadNotes("mine");
    }

    @Override protected void onResume() { super.onResume(); if (auth!=null && auth.getCurrentUser()!=null && recycler!=null) loadNotes(mode); }

    private void loadNotes(String newMode) {
        mode=newMode; notes.clear();
        section.setText(mode.equals("mine")?"My Notes":mode.equals("market")?"Explore Notes":"Purchased Notes");
        String uid=auth.getCurrentUser().getUid();
        if (mode.equals("mine")) {
            db.collection("notes").whereEqualTo("ownerId",uid).get()
                .addOnSuccessListener(result -> { for(DocumentSnapshot d:result) notes.add(fromDoc(d)); showNotes(); })
                .addOnFailureListener(e -> showError(e));
        } else if (mode.equals("market")) {
            db.collection("notes").whereEqualTo("isPublic",true).get()
                .addOnSuccessListener(result -> { for(DocumentSnapshot d:result) { Note n=fromDoc(d); if(!n.ownerId.equals(uid)) notes.add(n); } showNotes(); })
                .addOnFailureListener(e -> showError(e));
        } else {
            db.collection("purchases").whereEqualTo("buyerId",uid).get()
                .addOnSuccessListener(result -> {
                    for(DocumentSnapshot d:result) {
                        Note n=new Note(); n.id=d.getString("noteId"); n.title=d.getString("title");
                        n.subject=d.getString("subject"); n.content=d.getString("content");
                        Double p=d.getDouble("price"); n.price=p==null?0:p; notes.add(n);
                    }
                    showNotes();
                }).addOnFailureListener(e -> showError(e));
        }
    }

    private Note fromDoc(DocumentSnapshot d) {
        Note n=new Note(); n.id=d.getId(); n.title=d.getString("title"); n.subject=d.getString("subject");
        n.content=d.getString("content"); n.ownerId=d.getString("ownerId"); n.sellerEmail=d.getString("sellerEmail");
        Double p=d.getDouble("price"); n.price=p==null?0:p;
        n.isPublic=Boolean.TRUE.equals(d.getBoolean("isPublic")); return n;
    }
    private void showNotes() { recycler.setAdapter(new NoteAdapter(notes,mode,this)); }
    private void showError(Exception e) { Toast.makeText(this,e.getMessage(),Toast.LENGTH_LONG).show(); }

    @Override public void onOpen(Note note) {
        if (mode.equals("mine")) {
            Intent i=new Intent(this,AddEditNoteActivity.class); i.putExtra("noteId",note.id); startActivity(i);
        } else if (mode.equals("market")) showPurchaseDialog(note);
        else new AlertDialog.Builder(this).setTitle(note.title).setMessage(note.content).setPositiveButton("Close",null).show();
    }

    private void showPurchaseDialog(Note note) {
        String priceText=note.price<=0?"Free":"৳"+(long)note.price;
        new AlertDialog.Builder(this).setTitle(note.title)
            .setMessage("Subject: "+note.subject+"\n\n"+note.content+"\n\nPrice: "+priceText+"\n\nThis is a demo purchase. No real money will be charged.")
            .setNegativeButton("Cancel",null).setPositiveButton(note.price<=0?"Get note":"Buy demo",(dialog,which)->buyNote(note)).show();
    }

    private void buyNote(Note note) {
        String uid=auth.getCurrentUser().getUid();
        String purchaseId=uid+"_"+note.id;
        db.collection("purchases").document(purchaseId).get().addOnSuccessListener(existing -> {
            if(existing.exists()) { Toast.makeText(this,"You already have this note",Toast.LENGTH_SHORT).show(); return; }
            Map<String,Object> purchase=new HashMap<>();
            purchase.put("buyerId",uid); purchase.put("sellerId",note.ownerId); purchase.put("noteId",note.id);
            purchase.put("title",note.title); purchase.put("subject",note.subject); purchase.put("content",note.content);
            purchase.put("price",note.price); purchase.put("purchasedAt",System.currentTimeMillis());
            db.collection("purchases").document(purchaseId).set(purchase)
                .addOnSuccessListener(v -> { Toast.makeText(this,"Demo purchase successful!",Toast.LENGTH_LONG).show(); loadNotes("bought"); })
                .addOnFailureListener(this::showError);
        }).addOnFailureListener(this::showError);
    }

    @Override public void onShare(Note note) {
        String shareText=note.title+"\nSubject: "+note.subject+"\n\n"+note.content+"\n\nShared from NoteNest";
        Intent send=new Intent(Intent.ACTION_SEND); send.setType("text/plain"); send.putExtra(Intent.EXTRA_TEXT,shareText);
        startActivity(Intent.createChooser(send,"Share note with"));
    }
    private void openLogin() { startActivity(new Intent(this,LoginActivity.class)); finish(); }
}
