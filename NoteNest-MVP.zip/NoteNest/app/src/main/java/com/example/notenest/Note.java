package com.example.notenest;

public class Note {
    public String id = "", title = "", subject = "", content = "", ownerId = "", sellerEmail = "";
    public double price = 0;
    public boolean isPublic = false;
    public Note() {}
}
