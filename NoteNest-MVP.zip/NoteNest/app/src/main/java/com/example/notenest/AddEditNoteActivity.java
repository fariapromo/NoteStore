package com.example.notenest;

import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.firestore.FirebaseFirestore;
import java.util.HashMap;
import java.util.Map;

public class AddEditNoteActivity extends AppCompatActivity {
    private FirebaseFirestore db;
    private EditText title, subject, content, price;
    private Switch makePublic;
    private String noteId = null;

    @Override protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_edit_note);
        db = FirebaseFirestore.getInstance();
        title=findViewById(R.id.etTitle); subject=findViewById(R.id.etSubject);
        content=findViewById(R.id.etContent); price=findViewById(R.id.etPrice);
        makePublic=findViewById(R.id.swPublic);
        TextView heading=findViewById(R.id.tvEditorTitle);
        Button save=findViewById(R.id.btnSave);
        noteId=getIntent().getStringExtra("noteId");
        if (noteId != null) {
            heading.setText("Edit your note"); save.setText("Update note");
            db.collection("notes").document(noteId).get().addOnSuccessListener(doc -> {
                if (doc.exists()) {
                    title.setText(doc.getString("title")); subject.setText(doc.getString("subject"));
                    content.setText(doc.getString("content"));
                    makePublic.setChecked(Boolean.TRUE.equals(doc.getBoolean("isPublic")));
                    Double p=doc.getDouble("price"); price.setText(p == null ? "0" : String.valueOf(p));
                }
            });
        } else price.setText("0");
        save.setOnClickListener(v -> saveNote());
    }

    private void saveNote() {
        String t=title.getText().toString().trim(), s=subject.getText().toString().trim(), c=content.getText().toString().trim();
        if (t.isEmpty() || s.isEmpty() || c.isEmpty()) { Toast.makeText(this,"Fill title, subject and note content",Toast.LENGTH_SHORT).show(); return; }
        double p=0;
        try { p=Double.parseDouble(price.getText().toString().trim()); } catch (Exception ignored) {}
        if (p < 0) { Toast.makeText(this,"Price cannot be negative",Toast.LENGTH_SHORT).show(); return; }
        String uid=FirebaseAuth.getInstance().getCurrentUser().getUid();
        Map<String,Object> data=new HashMap<>();
        data.put("title",t); data.put("subject",s); data.put("content",c); data.put("price",p);
        data.put("isPublic",makePublic.isChecked()); data.put("ownerId",uid);
        data.put("sellerEmail",FirebaseAuth.getInstance().getCurrentUser().getEmail());
        data.put("updatedAt",System.currentTimeMillis());
        if (noteId == null) data.put("createdAt",System.currentTimeMillis());
        if (noteId == null) {
            db.collection("notes").add(data).addOnSuccessListener(ref -> finish())
                .addOnFailureListener(e -> Toast.makeText(this,e.getMessage(),Toast.LENGTH_LONG).show());
        } else {
            db.collection("notes").document(noteId).update(data).addOnSuccessListener(v -> finish())
                .addOnFailureListener(e -> Toast.makeText(this,e.getMessage(),Toast.LENGTH_LONG).show());
        }
    }
}
