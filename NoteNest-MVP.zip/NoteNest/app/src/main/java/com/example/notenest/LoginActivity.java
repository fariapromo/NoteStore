package com.example.notenest;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import com.google.firebase.auth.FirebaseAuth;

public class LoginActivity extends AppCompatActivity {
    private FirebaseAuth auth;
    private EditText etEmail, etPassword;

    @Override protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
        auth = FirebaseAuth.getInstance();
        if (auth.getCurrentUser() != null) { openHome(); return; }
        etEmail = findViewById(R.id.etEmail);
        etPassword = findViewById(R.id.etPassword);
        Button login = findViewById(R.id.btnLogin);
        Button register = findViewById(R.id.btnRegister);
        login.setOnClickListener(v -> signIn());
        register.setOnClickListener(v -> signUp());
    }

    private boolean validate() {
        String email = etEmail.getText().toString().trim();
        String password = etPassword.getText().toString().trim();
        if (email.isEmpty() || password.length() < 6) {
            Toast.makeText(this, "Enter a valid email and password (6+ characters)", Toast.LENGTH_LONG).show();
            return false;
        }
        return true;
    }
    private void signIn() {
        if (!validate()) return;
        auth.signInWithEmailAndPassword(etEmail.getText().toString().trim(), etPassword.getText().toString().trim())
            .addOnSuccessListener(result -> openHome())
            .addOnFailureListener(e -> Toast.makeText(this, e.getMessage(), Toast.LENGTH_LONG).show());
    }
    private void signUp() {
        if (!validate()) return;
        auth.createUserWithEmailAndPassword(etEmail.getText().toString().trim(), etPassword.getText().toString().trim())
            .addOnSuccessListener(result -> openHome())
            .addOnFailureListener(e -> Toast.makeText(this, e.getMessage(), Toast.LENGTH_LONG).show());
    }
    private void openHome() {
        startActivity(new Intent(this, MainActivity.class));
        finish();
    }
}
