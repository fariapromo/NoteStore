NOTENEST - Java + XML + Firebase MVP

Features:
- Email/password registration and login
- Create and edit personal notes
- Publish notes to a public marketplace
- Share note text using Android's share menu
- Browse public notes and make a DEMO purchase
- View purchased notes

IMPORTANT: Demo purchase does not collect money. Do not use it for real transactions.

SETUP
1. Open this folder in Android Studio (Open > select NoteNest folder).
2. Wait for Gradle sync. Use JDK 17 in Android Studio settings.
3. In Firebase Console create a project named NoteNest.
4. Add an Android app with package name: com.example.notenest
5. Download google-services.json and put it in NoteNest/app/google-services.json.
6. Firebase Console > Authentication > Get started > Sign-in method > enable Email/Password.
7. Firebase Console > Firestore Database > Create database.
8. Open Firestore Rules and paste the rules from FIRESTORE_RULES.txt, then Publish.
9. Run on an emulator or Android phone with internet.

FIRESTORE COLLECTIONS
- notes: title, subject, content, price, isPublic, ownerId, sellerEmail, createdAt, updatedAt
- purchases: buyerId, sellerId, noteId, title, subject, content, price, purchasedAt

If Gradle reports SDK 36 missing, install Android SDK Platform 36 from Tools > SDK Manager.
